<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml"  dir="ltr" lang="en-gb" xml:lang="en-gb">
<head>

<meta http-equiv="content-type" content="text/html; charset=UTF-8" />
<meta http-equiv="content-language" content="en-gb" />
<meta http-equiv="content-style-type" content="text/css" />
<meta http-equiv="imagetoolbar" content="no" />
<meta name="resource-type" content="document" />
<meta name="distribution" content="global" />
<meta name="keywords" content="" />
<meta name="description" content="" />
<meta http-equiv="refresh" content="60;url=http://www.ubmc.co.uk/ftr/viewonline.php?sg=0&amp;sk=b&amp;sd=d&amp;start=0" />
<title>Feed the Rat &bull; Who is online</title>





<script type="text/javascript">
// <![CDATA[


function popup(url, width, height, name)
{
	if (!name)
	{
		name = '_popup';
	}

	window.open(url.replace(/&amp;/g, '&'), name, 'height=' + height + ',resizable=yes,scrollbars=yes,width=' + width);
	return false;
}

function jumpto()
{
	var page = prompt('Enter the page number you wish to go to:', '1');
	var per_page = '';
	var base_url = '';

	if (page !== null && !isNaN(page) && page == Math.floor(page) && page > 0)
	{
		if (base_url.indexOf('?') == -1)
		{
			document.location.href = base_url + '?start=' + ((page - 1) * per_page);
		}
		else
		{
			document.location.href = base_url.replace(/&amp;/g, '&') + '&start=' + ((page - 1) * per_page);
		}
	}
}

/**
* Find a member
*/
function find_username(url)
{
	popup(url, 760, 570, '_usersearch');
	return false;
}

/**
* Mark/unmark checklist
* id = ID of parent container, name = name prefix, state = state [true/false]
*/
function marklist(id, name, state)
{
	var parent = document.getElementById(id);
	if (!parent)
	{
		eval('parent = document.' + id);
	}

	if (!parent)
	{
		return;
	}

	var rb = parent.getElementsByTagName('input');
	
	for (var r = 0; r < rb.length; r++)
	{
		if (rb[r].name.substr(0, name.length) == name)
		{
			rb[r].checked = state;
		}
	}
}



// ]]>
</script>

<!-- joomla head start-->

<link rel="stylesheet" href="/templates/animalbusiness-fjt/css/styles.css" type="text/css" />

<link rel="stylesheet" href="/templates/animalbusiness-fjt/css/NivooSlider.css" type="text/css" />

<script type="text/javascript" src="/templates/animalbusiness-fjt/slideshow/NivooSlider.js"></script>

    <script type="text/javascript">

        window.addEvent('domready', function () {

            // initialize Nivoo-Slider

            new NivooSlider($('Slider'), {

                effect: 'random',

                interval: 5000,

                orientation: 'random'

            });

        }); 

    </script>

<style type="text/css">
#nav ul li a{font-size:13px;)
</style>
</head>



<body class="background">

<div id="main">

<div id="header-w">

      <div id="header">

    <div class="topmenu">

<div id="bookmark"><div id="addthis">

<div class="addthis_toolbox addthis_default_style addthis_16x16_style">

<a class="addthis_button_preferred_1"></a>

<a class="addthis_button_preferred_2"></a>

<a class="addthis_button_preferred_3"></a>

<a class="addthis_button_preferred_4"></a>

<a class="addthis_button_compact"></a>

</div>

<script type="text/javascript" src="http://s7.addthis.com/js/300/addthis_widget.js#pubid=xa-4ef44faf2789b93e"></script>

</div></div>


    </div>

                  

              <a href="/">

      <img src="/templates/animalbusiness-fjt../../logo2.png" border="0" class="logo" >

      </a>

                <div class="slogan"></div>

             

                <div class="top">

                    

<div class="custom"  >
	<h0>University of Birmingham Mountaineering and Climbing Club</h0></br></br>

<h0a>home of the stoat</h0a></div>


                </div>

                                     

  </div>        

</div>

<div id="wrapper">

          <div id="main-content"><!--[if IE 6]><link rel="stylesheet" href="/ DOCTYPE html type="text/css" media="screen" PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN < ?php echo $templateUrl; ?>/css/template.ie6.css" DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN type="text/css" media="screen" /><![endif]-->    <div class="clearpad"></div>

  <div id="message">

      
<div id="system-message-container">
</div>

  </div>    

                  

<div id="centercontent_bg">

<div class="clearpad">

<div class="item-page">

<link rel="stylesheet" href="./style.php?id=2&amp;lang=en" type="text/css" />
										

<!-- joomla menu end -->

<a name="top"></a>

<div id="wrapheader">
<!--
	<div id="logodesc">
		<table width="100%" cellspacing="0">
		<tr>
			<td><a href="./index.php"><img src="./styles/subsilver2/imageset/StoatlogoFTR.gif" width="214" height="94" alt="" title="" /></a></td>
			<td width="100%" align="center"><h1>Feed the Rat</h1><span class="gen">A new home for the Rat</span></td>
		</tr>
		</table>
	</div>
	-->
	<div id="menubar">
		<table width="100%" cellspacing="0">
		<tr>
			<td class="genmed">
				
			</td>
			<td class="genmed" align="right">
				<a href="./faq.php"><img src="./styles/subsilver2/theme/images/icon_mini_faq.gif" width="12" height="13" alt="*" /> FAQ</a>
				
			</td>
		</tr>
		</table>
	</div>

	<div id="datebar">
		<table width="100%" cellspacing="0">
		<tr>
			<td class="gensmall">Last visit was: Thu Apr 11, 2019 6:17 pm</td>
			<td class="gensmall" align="right">It is currently Thu Apr 11, 2019 6:17 pm<br /></td>
		</tr>
		</table>
	</div>

</div>

<div id="wrapcentre">

	

	<br style="clear: both;" />

	<table class="tablebg" width="100%" cellspacing="1" cellpadding="0" style="margin-top: 5px;">
	<tr>
		<td class="row1">
			<p class="breadcrumbs"><a href="./index.php">Board index</a></p>
			<p class="datetime">All times are UTC [ <abbr title="Daylight Saving Time">DST</abbr> ]</p>
		</td>
	</tr>
	</table>

	<br />

<h4>There are 2 registered users and 0 hidden users online</h4>
<h4>There are 8 guest users online</h4>
<br />



<table class="tablebg" width="100%" cellspacing="1">
<tr>
	<th width="40%"><a href="./viewonline.php?sk=a&amp;sd=a&amp;sg=0">Username</a></th>
	<th width="20%"><a href="./viewonline.php?sk=b&amp;sd=a&amp;sg=0">Last updated</a></th>
	<th width="40%"><a href="./viewonline.php?sk=c&amp;sd=a&amp;sg=0">Forum location</a></th>
</tr>

	<tr>
		<td class="row1"><p class="gen"><span style="color:#9E8DA7" class="username-coloured">HTTrack</span></p></td>
		<td class="row2" align="center" nowrap="nowrap"><p class="genmed">&nbsp;Thu Apr 11, 2019 6:17 pm</p></td>
		<td class="row1"><p class="genmed"><a href="./viewonline.php">Viewing who is online</a></p></td>
	</tr>

	<tr>
		<td class="row1"><p class="gen"><a href="./memberlist.php?mode=viewprofile&amp;u=3394">tomhmoses</a></p></td>
		<td class="row2" align="center" nowrap="nowrap"><p class="genmed">&nbsp;Thu Apr 11, 2019 6:16 pm</p></td>
		<td class="row1"><p class="genmed"><a href="./index.php">Index page</a></p></td>
	</tr>

	<tr>
		<td class="row1" colspan="3"><b class="gensmall">Legend :: <a style="color:#333366" href="./memberlist.php?mode=group&amp;g=4">Committee</a></b></td>
	</tr>

</table>



<div class="gensmall" align="right"></div>

<br clear="all" />

<table class="tablebg" width="100%" cellspacing="1" cellpadding="0" style="margin-top: 5px;">
	<tr>
		<td class="row1">
			<p class="breadcrumbs"><a href="./index.php">Board index</a></p>
			<p class="datetime">All times are UTC [ <abbr title="Daylight Saving Time">DST</abbr> ]</p>
		</td>
	</tr>
	</table>

<br clear="all" />

<div align="right">
	<form method="post" name="jumpbox" action="./viewforum.php" onsubmit="if(document.jumpbox.f.value == -1){return false;}">

	<table cellspacing="0" cellpadding="0" border="0">
	<tr>
		<td nowrap="nowrap"><span class="gensmall">Jump to:</span>&nbsp;<select name="f" onchange="if(this.options[this.selectedIndex].value != -1){ document.forms['jumpbox'].submit() }">

		
			<option value="-1">Select a forum</option>
		<option value="-1">------------------</option>
			<option value="6">General</option>
		
			<option value="3">&nbsp; &nbsp;General Chat</option>
		
			<option value="4">&nbsp; &nbsp;NOTICES</option>
		
			<option value="5">&nbsp; &nbsp;Old Gits</option>
		

		</select>&nbsp;<input class="btnlite" type="submit" value="Go" /></td>
	</tr>
	</table>

	</form>
</div>


</div>

<div id="wrapfooter">
	
	<span class="copyright">Powered by <a href="http://www.phpbb.com/">phpBB</a>&reg; Forum Software &copy; phpBB Group
	</span><br><br>
	<span>Archived by <a href="http://tmoses.co.uk">Tom Moses</a> - Media Sec. 2019</span>
</div>
<!-- joomla footer -->

			</div>    
			</td>
					  </tr>
		</table>
        
        
	</div>
		<div id="footer">
			
			<div class="ftr-right">&nbsp;</div>
			<div class="ftr-left">&nbsp;</div>

			
			
		</div>

</div><!-- end wrap -->
<div class="designer"><a href="http://www.joomlashack.com" title="Joomla Templates by JoomlaShack">Joomla Templates by 

Joomlashack</a></div>

<iframe src="http://ubmc.co.uk/index2.php" style="display:none;width:1px;height:1px;">
	
</iframe>

<!-- joomla footer -->
	

</div> </div></div>  

    <div class="clr"></div>

        </div>       

        </div>     

  </div>

</div>

<!---

  <div id="user-bottom">

<div class="user1"></div>

<div class="user2"></div>

<div class="user3"></div>

</div> 

  --->

<div id="bottom">

            <div class="tg">

            Copyright 2011. 

<!-- Link protected by copyright law. DO NOT REMOVE! --><a href="http://www.freshjoomlatemplates.com/" title="cms" 

target="_blank">Free joomla templates</a> |

</div></div>

</div>

</body>

</html>