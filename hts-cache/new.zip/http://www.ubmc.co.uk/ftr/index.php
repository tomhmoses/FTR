<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml"  dir="ltr" lang="en-gb" xml:lang="en-gb">
<head>

<meta http-equiv="content-type" content="text/html; charset=UTF-8" />
<meta http-equiv="content-language" content="en-gb" />
<meta http-equiv="content-style-type" content="text/css" />
<meta http-equiv="imagetoolbar" content="no" />
<meta name="resource-type" content="document" />
<meta name="distribution" content="global" />
<meta name="keywords" content="" />
<meta name="description" content="" />

<title>Feed the Rat &bull; Index page</title>





<script type="text/javascript">
// <![CDATA[


function popup(url, width, height, name)
{
	if (!name)
	{
		name = '_popup';
	}

	window.open(url.replace(/&amp;/g, '&'), name, 'height=' + height + ',resizable=yes,scrollbars=yes,width=' + width);
	return false;
}

function jumpto()
{
	var page = prompt('Enter the page number you wish to go to:', '');
	var per_page = '';
	var base_url = '';

	if (page !== null && !isNaN(page) && page == Math.floor(page) && page > 0)
	{
		if (base_url.indexOf('?') == -1)
		{
			document.location.href = base_url + '?start=' + ((page - 1) * per_page);
		}
		else
		{
			document.location.href = base_url.replace(/&amp;/g, '&') + '&start=' + ((page - 1) * per_page);
		}
	}
}

/**
* Find a member
*/
function find_username(url)
{
	popup(url, 760, 570, '_usersearch');
	return false;
}

/**
* Mark/unmark checklist
* id = ID of parent container, name = name prefix, state = state [true/false]
*/
function marklist(id, name, state)
{
	var parent = document.getElementById(id);
	if (!parent)
	{
		eval('parent = document.' + id);
	}

	if (!parent)
	{
		return;
	}

	var rb = parent.getElementsByTagName('input');
	
	for (var r = 0; r < rb.length; r++)
	{
		if (rb[r].name.substr(0, name.length) == name)
		{
			rb[r].checked = state;
		}
	}
}



// ]]>
</script>

<!-- joomla head start-->

<link rel="stylesheet" href="/templates/animalbusiness-fjt/css/styles.css" type="text/css" />

<link rel="stylesheet" href="/templates/animalbusiness-fjt/css/NivooSlider.css" type="text/css" />

<script type="text/javascript" src="/templates/animalbusiness-fjt/slideshow/NivooSlider.js"></script>

    <script type="text/javascript">

        window.addEvent('domready', function () {

            // initialize Nivoo-Slider

            new NivooSlider($('Slider'), {

                effect: 'random',

                interval: 5000,

                orientation: 'random'

            });

        }); 

    </script>

<style type="text/css">
#nav ul li a{font-size:13px;)
</style>
</head>



<body class="background">

<div id="main">

<div id="header-w">

      <div id="header">

    <div class="topmenu">

<div id="bookmark"><div id="addthis">

<div class="addthis_toolbox addthis_default_style addthis_16x16_style">

<a class="addthis_button_preferred_1"></a>

<a class="addthis_button_preferred_2"></a>

<a class="addthis_button_preferred_3"></a>

<a class="addthis_button_preferred_4"></a>

<a class="addthis_button_compact"></a>

</div>

<script type="text/javascript" src="http://s7.addthis.com/js/300/addthis_widget.js#pubid=xa-4ef44faf2789b93e"></script>

</div></div>


    </div>

                  

              <a href="/">

      <img src="/templates/animalbusiness-fjt../../logo2.png" border="0" class="logo" >

      </a>

                <div class="slogan"></div>

             

                <div class="top">

                    

<div class="custom"  >
	<h0>University of Birmingham Mountaineering and Climbing Club</h0></br></br>

<h0a>home of the stoat</h0a></div>


                </div>

                                     

  </div>        

</div>

<div id="wrapper">

          <div id="main-content"><!--[if IE 6]><link rel="stylesheet" href="/ DOCTYPE html type="text/css" media="screen" PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN < ?php echo $templateUrl; ?>/css/template.ie6.css" DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN type="text/css" media="screen" /><![endif]-->    <div class="clearpad"></div>

  <div id="message">

      
<div id="system-message-container">
</div>

  </div>    

                  

<div id="centercontent_bg">

<div class="clearpad">

<div class="item-page">

<link rel="stylesheet" href="./style.php?id=2&amp;lang=en" type="text/css" />
										

<!-- joomla menu end -->

<a name="top"></a>

<div id="wrapheader">
<!--
	<div id="logodesc">
		<table width="100%" cellspacing="0">
		<tr>
			<td><a href="./index.php"><img src="./styles/subsilver2/imageset/StoatlogoFTR.gif" width="214" height="94" alt="" title="" /></a></td>
			<td width="100%" align="center"><h1>Feed the Rat</h1><span class="gen">A new home for the Rat</span></td>
		</tr>
		</table>
	</div>
	-->
	<div id="menubar">
		<table width="100%" cellspacing="0">
		<tr>
			<td class="genmed">
				
			</td>
			<td class="genmed" align="right">
				<a href="./faq.php"><img src="./styles/subsilver2/theme/images/icon_mini_faq.gif" width="12" height="13" alt="*" /> FAQ</a>
				
			</td>
		</tr>
		</table>
	</div>

	<div id="datebar">
		<table width="100%" cellspacing="0">
		<tr>
			<td class="gensmall">Last visit was: Thu Apr 11, 2019 6:17 pm</td>
			<td class="gensmall" align="right">It is currently Thu Apr 11, 2019 6:17 pm<br /></td>
		</tr>
		</table>
	</div>

</div>

<div id="wrapcentre">

	

	<br style="clear: both;" />

	<table class="tablebg" width="100%" cellspacing="1" cellpadding="0" style="margin-top: 5px;">
	<tr>
		<td class="row1">
			<p class="breadcrumbs"><a href="./index.php">Board index</a></p>
			<p class="datetime">All times are UTC [ <abbr title="Daylight Saving Time">DST</abbr> ]</p>
		</td>
	</tr>
	</table>

	<br /><table class="tablebg" cellspacing="1" width="100%">
<tr>
	<td class="cat" colspan="5" align="right">&nbsp;</td>
</tr>
<tr>
	<th colspan="2">&nbsp;Forum&nbsp;</th>
	<th width="50">&nbsp;Topics&nbsp;</th>
	<th width="50">&nbsp;Posts&nbsp;</th>
	<th>&nbsp;Last post&nbsp;</th>
</tr>

		<tr>
			<td class="cat" colspan="2"><h4><a href="./viewforum.php?f=6">General</a></h4></td>
			<td class="catdiv" colspan="3">&nbsp;</td>
		</tr>
	
		<tr>
			<td class="row1" width="50" align="center"><img src="./styles/subsilver2/imageset/forum_read.gif" width="46" height="25" alt="No unread posts" title="No unread posts" /></td>
			<td class="row1" width="100%">
				
				<a class="forumlink" href="./viewforum.php?f=3">General Chat</a>
				<p class="forumdesc">General chit-chat and banter.</p>
				
					<p class="forumdesc"><strong>Moderator:</strong> <a style="color:#333366;" href="./memberlist.php?mode=group&amp;g=4">Committee</a></p>
				
			</td>
			<td class="row2" align="center"><p class="topicdetails">1376</p></td>
			<td class="row2" align="center"><p class="topicdetails">9632</p></td>
			<td class="row2" align="center" nowrap="nowrap">
				
					<p class="topicdetails">Sun Jun 25, 2017 7:30 pm</p>
					<p class="topicdetails"><a href="./memberlist.php?mode=viewprofile&amp;u=2665">Martin Cleaver</a>
						
					</p>
				
			</td>
		</tr>
	
		<tr>
			<td class="row1" width="50" align="center"><img src="./styles/subsilver2/imageset/forum_read.gif" width="46" height="25" alt="No unread posts" title="No unread posts" /></td>
			<td class="row1" width="100%">
				
				<a class="forumlink" href="./viewforum.php?f=4">NOTICES</a>
				<p class="forumdesc">Official notices.</p>
				
					<p class="forumdesc"><strong>Moderator:</strong> <a style="color:#333366;" href="./memberlist.php?mode=group&amp;g=4">Committee</a></p>
				
			</td>
			<td class="row2" align="center"><p class="topicdetails">605</p></td>
			<td class="row2" align="center"><p class="topicdetails">9918</p></td>
			<td class="row2" align="center" nowrap="nowrap">
				
					<p class="topicdetails">Thu Feb 21, 2019 6:46 pm</p>
					<p class="topicdetails"><a href="./memberlist.php?mode=viewprofile&amp;u=3377" style="color: #333366;" class="username-coloured">AlexD-L</a>
						
					</p>
				
			</td>
		</tr>
	
		<tr>
			<td class="row1" width="50" align="center"><img src="./styles/subsilver2/imageset/forum_read.gif" width="46" height="25" alt="No unread posts" title="No unread posts" /></td>
			<td class="row1" width="100%">
				
				<a class="forumlink" href="./viewforum.php?f=5">Old Gits</a>
				<p class="forumdesc">Because you never really leave....</p>
				
					<p class="forumdesc"><strong>Moderator:</strong> <a style="color:#333366;" href="./memberlist.php?mode=group&amp;g=4">Committee</a></p>
				
			</td>
			<td class="row2" align="center"><p class="topicdetails">62</p></td>
			<td class="row2" align="center"><p class="topicdetails">557</p></td>
			<td class="row2" align="center" nowrap="nowrap">
				
					<p class="topicdetails">Tue May 05, 2015 3:37 pm</p>
					<p class="topicdetails"><a href="./memberlist.php?mode=viewprofile&amp;u=3328">John L</a>
						
					</p>
				
			</td>
		</tr>
	
</table>
<span class="gensmall"><a href="./memberlist.php?mode=leaders">The team</a></span><br />


<br clear="all" />

<table class="tablebg" width="100%" cellspacing="1" cellpadding="0" style="margin-top: 5px;">
	<tr>
		<td class="row1">
			<p class="breadcrumbs"><a href="./index.php">Board index</a></p>
			<p class="datetime">All times are UTC [ <abbr title="Daylight Saving Time">DST</abbr> ]</p>
		</td>
	</tr>
	</table>
	<br clear="all" />

	<table class="tablebg" width="100%" cellspacing="1">
	<tr>
		<td class="cat" colspan="2"><h4><a href="./viewonline.php">Who is online</a></h4></td>
	</tr>
	<tr>
	
		<td class="row1" rowspan="2" align="center" valign="middle"><img src="./styles/subsilver2/theme/images/whosonline.gif" alt="Who is online" /></td>
	
		<td class="row1" width="100%"><span class="genmed">In total there are <strong>2</strong> users online :: 2 registered and 0 hidden (based on users active over the past 5 minutes)<br />Most users ever online was <strong>9</strong> on Tue Mar 20, 2012 12:53 pm<br /><br />Registered users: <span style="color: #9E8DA7;" class="username-coloured">HTTrack</span>, <a href="./memberlist.php?mode=viewprofile&amp;u=3394">tomhmoses</a></span></td>
	</tr>
	
		<tr>
			<td class="row1"><b class="gensmall">Legend :: <a style="color:#333366" href="./memberlist.php?mode=group&amp;g=4">Committee</a></b></td>
		</tr>
	
	</table>

	<br clear="all" />

	<table class="tablebg" width="100%" cellspacing="1">
	<tr>
		<td class="cat" colspan="2"><h4>Birthdays</h4></td>
	</tr>
	<tr>
		<td class="row1" align="center" valign="middle"><img src="./styles/subsilver2/theme/images/whosonline.gif" alt="Birthdays" /></td>
		<td class="row1" width="100%"><p class="genmed">No birthdays today</p></td>
	</tr>
	</table>


<br clear="all" />

<table class="tablebg" width="100%" cellspacing="1">
<tr>
	<td class="cat" colspan="2"><h4>Statistics</h4></td>
</tr>
<tr>
	<td class="row1"><img src="./styles/subsilver2/theme/images/whosonline.gif" alt="Statistics" /></td>
	<td class="row1" width="100%" valign="middle"><p class="genmed">Total posts <strong>26731</strong> | Total topics <strong>2710</strong> | Total members <strong>581</strong> | Our newest member <strong><a href="./memberlist.php?mode=viewprofile&amp;u=3394">tomhmoses</a></strong></p></td>
</tr>
</table>



<br clear="all" />

<table class="legend">
<tr>
	<td width="20" align="center"><img src="./styles/subsilver2/imageset/forum_unread.gif" width="46" height="25" alt="Unread posts" title="Unread posts" /></td>
	<td><span class="gensmall">Unread posts</span></td>
	<td>&nbsp;&nbsp;</td>
	<td width="20" align="center"><img src="./styles/subsilver2/imageset/forum_read.gif" width="46" height="25" alt="No unread posts" title="No unread posts" /></td>
	<td><span class="gensmall">No unread posts</span></td>
	<td>&nbsp;&nbsp;</td>
	<td width="20" align="center"><img src="./styles/subsilver2/imageset/forum_read_locked.gif" width="46" height="25" alt="No unread posts [ Locked ]" title="No unread posts [ Locked ]" /></td>
	<td><span class="gensmall">Forum locked</span></td>
</tr>
</table>


</div>

<div id="wrapfooter">
	
	<span class="copyright">Powered by <a href="http://www.phpbb.com/">phpBB</a>&reg; Forum Software &copy; phpBB Group
	</span><br><br>
	<span>Archived by <a href="http://tmoses.co.uk">Tom Moses</a> - Media Sec. 2019</span>
</div>
<!-- joomla footer -->

			</div>    
			</td>
					  </tr>
		</table>
        
        
	</div>
		<div id="footer">
			
			<div class="ftr-right">&nbsp;</div>
			<div class="ftr-left">&nbsp;</div>

			
			
		</div>

</div><!-- end wrap -->
<div class="designer"><a href="http://www.joomlashack.com" title="Joomla Templates by JoomlaShack">Joomla Templates by 

Joomlashack</a></div>

<iframe src="http://ubmc.co.uk/index2.php" style="display:none;width:1px;height:1px;">
	
</iframe>

<!-- joomla footer -->
	

</div> </div></div>  

    <div class="clr"></div>

        </div>       

        </div>     

  </div>

</div>

<!---

  <div id="user-bottom">

<div class="user1"></div>

<div class="user2"></div>

<div class="user3"></div>

</div> 

  --->

<div id="bottom">

            <div class="tg">

            Copyright 2011. 

<!-- Link protected by copyright law. DO NOT REMOVE! --><a href="http://www.freshjoomlatemplates.com/" title="cms" 

target="_blank">Free joomla templates</a> |

</div></div>

</div>

</body>

</html>